export const SELECT_TOOL ="SELECT_TOOL";
export const CHANGE_SIZE ="CHANGE_SIZE";
export const CHANGE_COLOR ="CHANGE_COLOR";
export const RESET ="RESET";
