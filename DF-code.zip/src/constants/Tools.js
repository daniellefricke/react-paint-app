export const BRUSH = "BRUSH";
export const STAMP = "STAMP";
export const ERASER = "ERASER";
