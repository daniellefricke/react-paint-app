import { combineReducers } from "redux";
import tools from "./tools";

const rootReducer = combineReducers({
	tools
});

export default rootReducer;
